package com.gpstracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.location.LocationManager
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {

    private lateinit var minutes: EditText
    private lateinit var erreur: TextView
    private lateinit var statut: TextView
    private lateinit var btn: MaterialButton
    private lateinit var chips: ChipGroup
    private lateinit var moins: MaterialButton
    private lateinit var plus: MaterialButton

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) startRecording()
        else Toast.makeText(this, "Autorisez la position précise pour enregistrer", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        minutes = findViewById(R.id.minutes)
        erreur = findViewById(R.id.erreur)
        statut = findViewById(R.id.statut)
        btn = findViewById(R.id.btn)
        chips = findViewById(R.id.chips)
        moins = findViewById(R.id.moins)
        plus = findViewById(R.id.plus)

        chips.isSingleSelection = true
        chips.isSelectionRequired = true
        Store.MODES.forEachIndexed { i, m ->
            val chip = Chip(this).apply {
                text = m.first
                isCheckable = true
                textSize = 16f
                chipMinHeight = 48f * resources.displayMetrics.density
                id = 1000 + i
            }
            chips.addView(chip)
        }
        chips.check(1000)

        moins.setOnClickListener { minutes.setText(((minutes.text.toString().toIntOrNull() ?: 0) - 1).coerceIn(0, 60).toString()); validate() }
        plus.setOnClickListener { minutes.setText(((minutes.text.toString().toIntOrNull() ?: 0) + 1).coerceIn(0, 60).toString()); validate() }

        btn.setOnClickListener {
            if (LocationService.running) {
                startService(Intent(this, LocationService::class.java).setAction(LocationService.ACTION_STOP))
                render(false)
            } else if (validate() != null) {
                val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                if (fine == PackageManager.PERMISSION_GRANTED) startRecording()
                else permissions.launch(arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.POST_NOTIFICATIONS
                ))
            }
        }
        findViewById<MaterialButton>(R.id.records).setOnClickListener {
            startActivity(Intent(this, RecordsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        render(LocationService.running)
    }

    private fun validate(): Int? {
        val v = minutes.text.toString().toIntOrNull()
        return if (v == null || v !in 0..60) {
            erreur.text = "Entrez un nombre entier entre 0 et 60"; null
        } else { erreur.text = ""; v }
    }

    private fun startRecording() {
        val m = validate() ?: return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Activez le GPS du téléphone", Toast.LENGTH_LONG).show(); return
        }
        val idx = (chips.checkedChipId - 1000).coerceIn(0, Store.MODES.lastIndex)
        val i = Intent(this, LocationService::class.java)
            .putExtra(LocationService.EXTRA_MINUTES, m)
            .putExtra(LocationService.EXTRA_MODE, Store.MODES[idx].second)
        ContextCompat.startForegroundService(this, i)
        render(true)
    }

    private fun render(rec: Boolean) {
        btn.text = if (rec) "Arrêter" else "Démarrer"
        btn.backgroundTintList = ColorStateList.valueOf(Color.parseColor(if (rec) "#E24B4A" else "#888780"))
        statut.text = if (rec) "Enregistrement en cours" else "Prêt à enregistrer"
        minutes.isEnabled = !rec
        moins.isEnabled = !rec
        plus.isEnabled = !rec
        for (i in 0 until chips.childCount) chips.getChildAt(i).isEnabled = !rec
    }
}
