package com.gpstracker

import org.mapsforge.core.graphics.Canvas
import org.mapsforge.core.graphics.Paint
import org.mapsforge.core.graphics.Style
import org.mapsforge.core.model.BoundingBox
import org.mapsforge.core.model.LatLong
import org.mapsforge.core.model.Point
import org.mapsforge.core.util.MercatorProjection
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.layer.Layer
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

// Dessine les points GPS (bleu clair = point seul, bleu foncé = points très proches regroupés)
// et, si demandé, la trace fléchée qui les relie dans l'ordre.
class PointsLayer(
    private val pts: List<LatLong>,
    private val tileSize: Int,
    private val density: Float,
    private val onSelect: (LatLong, String) -> Unit
) : Layer() {

    var showTrace = false

    private class Cl(val min: Int) {
        var n = 0
        var max = min
        var sx = 0.0
        var sy = 0.0
        fun label(): String = if (min == max) "${min + 1}" else "${min + 1}-${max + 1}"
    }

    private val gf = AndroidGraphicFactory.INSTANCE

    private fun paint(color: Int, style: Style, width: Float = 0f): Paint {
        val p = gf.createPaint()
        p.setColor(color)
        p.setStyle(style)
        if (width > 0f) p.setStrokeWidth(width)
        return p
    }

    private val light = paint(0xFF85B7EB.toInt(), Style.FILL)
    private val dark = paint(0xFF0C447C.toInt(), Style.FILL)
    private val white = paint(0xFFFFFFFF.toInt(), Style.FILL)
    private val lineWhite = paint(0xCCFFFFFF.toInt(), Style.STROKE, 9f * density)
    private val lineBlue = paint(0xFF185FA5.toInt(), Style.STROKE, 5f * density)
    private val arrowFill = paint(0xFF185FA5.toInt(), Style.FILL)
    private val arrowEdge = paint(0xFFFFFFFF.toInt(), Style.STROKE, 2f * density)

    @Volatile private var drawn: List<Triple<Double, Double, String>> = emptyList()
    @Volatile private var lastMapSize = 0L

    override fun draw(boundingBox: BoundingBox, zoomLevel: Byte, canvas: Canvas, topLeftPoint: Point) {
        val n = pts.size
        if (n == 0) return
        val mapSize = MercatorProjection.getMapSize(zoomLevel, tileSize)
        lastMapSize = mapSize
        val ax = DoubleArray(n) { MercatorProjection.longitudeToPixelX(pts[it].longitude, mapSize) }
        val ay = DoubleArray(n) { MercatorProjection.latitudeToPixelY(pts[it].latitude, mapSize) }
        val ox = topLeftPoint.x
        val oy = topLeftPoint.y
        val w = canvas.width
        val h = canvas.height

        if (showTrace && n > 1) {
            for (pass in 0..1) {
                val paint = if (pass == 0) lineWhite else lineBlue
                for (i in 0 until n - 1) {
                    canvas.drawLine(
                        (ax[i] - ox).toInt(), (ay[i] - oy).toInt(),
                        (ax[i + 1] - ox).toInt(), (ay[i + 1] - oy).toInt(), paint
                    )
                }
            }
            var acc = 0.0
            val path = gf.createPath()
            for (i in 0 until n - 1) {
                val dx = ax[i + 1] - ax[i]
                val dy = ay[i + 1] - ay[i]
                val len = hypot(dx, dy)
                acc += len
                if (acc >= 70 * density && len >= 14 * density) {
                    acc = 0.0
                    val mx = (ax[i] + ax[i + 1]) / 2 - ox
                    val my = (ay[i] + ay[i + 1]) / 2 - oy
                    if (mx < 0 || my < 0 || mx > w || my > h) continue
                    val a = atan2(dy, dx)
                    val s = 8.0 * density
                    path.clear()
                    path.moveTo((mx + cos(a) * s * 1.3).toFloat(), (my + sin(a) * s * 1.3).toFloat())
                    path.lineTo((mx + cos(a + 2.5) * s).toFloat(), (my + sin(a + 2.5) * s).toFloat())
                    path.lineTo((mx + cos(a - 2.5) * s).toFloat(), (my + sin(a - 2.5) * s).toFloat())
                    path.close()
                    canvas.drawPath(path, arrowFill)
                    canvas.drawPath(path, arrowEdge)
                }
            }
        }

        // Regroupement des points proches (grille de ~16 px à l'écran)
        val cell = 16.0 * density
        val cells = HashMap<Long, Cl>()
        for (i in 0 until n) {
            val sx = ax[i] - ox
            val sy = ay[i] - oy
            if (sx < -30 || sy < -30 || sx > w + 30 || sy > h + 30) continue
            val key = (Math.floor(sx / cell).toLong() shl 32) xor (Math.floor(sy / cell).toLong() and 0xffffffffL)
            val c = cells.getOrPut(key) { Cl(i) }
            c.n++
            c.max = i
            c.sx += ax[i]
            c.sy += ay[i]
        }
        val result = ArrayList<Triple<Double, Double, String>>()
        val rOut = (11 * density).toInt()
        val rIn = (9 * density).toInt()
        for (c in cells.values) {
            val cx = c.sx / c.n
            val cy = c.sy / c.n
            val px = (cx - ox).toInt()
            val py = (cy - oy).toInt()
            canvas.drawCircle(px, py, rOut, white)
            canvas.drawCircle(px, py, rIn, if (c.n > 1) dark else light)
            result.add(Triple(cx, cy, c.label()))
        }
        drawn = result
    }

    override fun onTap(tapLatLong: LatLong, layerXY: Point, tapXY: Point): Boolean {
        val ms = lastMapSize
        if (ms == 0L) return false
        val tx = MercatorProjection.longitudeToPixelX(tapLatLong.longitude, ms)
        val ty = MercatorProjection.latitudeToPixelY(tapLatLong.latitude, ms)
        var best: Triple<Double, Double, String>? = null
        val reach = 28.0 * density
        var bd = reach * reach
        for (c in drawn) {
            val d = (c.first - tx) * (c.first - tx) + (c.second - ty) * (c.second - ty)
            if (d < bd) { bd = d; best = c }
        }
        val b = best ?: return false
        val ll = LatLong(
            MercatorProjection.pixelYToLatitude(b.second, ms),
            MercatorProjection.pixelXToLongitude(b.first, ms)
        )
        onSelect(ll, b.third)
        return true
    }
}
