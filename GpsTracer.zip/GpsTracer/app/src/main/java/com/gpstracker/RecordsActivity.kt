package com.gpstracker

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordsActivity : AppCompatActivity() {

    private lateinit var liste: LinearLayout
    private lateinit var vide: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_records)
        liste = findViewById(R.id.liste)
        vide = findViewById(R.id.vide)
        findViewById<ImageButton>(R.id.back).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        liste.removeAllViews()
        val files = Store.dir(this).listFiles { f -> f.extension == "xlsx" }
            .orEmpty().sortedByDescending { it.lastModified() }
        vide.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        for (f in files) {
            val row = layoutInflater.inflate(R.layout.item_record, liste, false)
            row.findViewById<TextView>(R.id.nom).text = f.nameWithoutExtension
            row.findViewById<TextView>(R.id.infos).text =
                fmt.format(Date(f.lastModified())) + " · " + (f.length() / 1024).coerceAtLeast(1) + " Ko"
            row.findViewById<ImageButton>(R.id.carte).setOnClickListener {
                startActivity(Intent(this, MapActivity::class.java).putExtra(MapActivity.EXTRA_NAME, f.nameWithoutExtension))
            }
            row.findViewById<ImageButton>(R.id.telecharger).setOnClickListener { download(f) }
            row.findViewById<ImageButton>(R.id.supprimer).setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Supprimer cet enregistrement ?")
                    .setMessage(f.nameWithoutExtension)
                    .setPositiveButton("Supprimer") { _, _ ->
                        f.delete()
                        Store.ptsFile(f).delete()
                        refresh()
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
            liste.addView(row)
        }
    }

    private fun download(f: File) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Téléchargement impossible", Toast.LENGTH_LONG).show(); return
        }
        contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
        Toast.makeText(this, "${f.name} enregistré dans Téléchargements", Toast.LENGTH_LONG).show()
    }
}
