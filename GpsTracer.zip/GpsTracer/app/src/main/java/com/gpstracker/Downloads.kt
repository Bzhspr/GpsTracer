package com.gpstracker

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

// Téléchargements de cartes en arrière-plan (un fil par zone)
object Downloads {
    val progress = ConcurrentHashMap<String, Int>()
    private val cancelled = ConcurrentHashMap.newKeySet<String>()
    @Volatile var listener: (() -> Unit)? = null
    @Volatile var error: String? = null

    fun cancel(id: String) { cancelled.add(id) }

    fun start(ctx: Context, z: Zone) {
        if (progress.containsKey(z.id)) return
        val dir = Store.maps(ctx.applicationContext)
        progress[z.id] = 0
        listener?.invoke()
        Thread {
            val out = File(dir, z.id + ".map")
            val part = File(dir, z.id + ".part")
            try {
                val conn = URL(z.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", "GpsTracer/2.0")
                if (conn.responseCode != 200) throw IOException("HTTP " + conn.responseCode)
                val total = conn.contentLengthLong
                conn.inputStream.use { input ->
                    part.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        var read = 0L
                        var last = -1
                        while (true) {
                            if (cancelled.remove(z.id)) throw IOException("annulé")
                            val n = input.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            read += n
                            if (total > 0) {
                                val p = (read * 100 / total).toInt()
                                if (p != last) { last = p; progress[z.id] = p; listener?.invoke() }
                            }
                        }
                    }
                }
                if (total > 0 && part.length() != total) throw IOException("fichier incomplet")
                if (!part.renameTo(out)) throw IOException("renommage impossible")
            } catch (e: Exception) {
                part.delete()
                if (e.message != "annulé") error = z.name
            } finally {
                progress.remove(z.id)
                listener?.invoke()
            }
        }.start()
    }
}
