package com.gpstracker

data class Zone(
    val id: String,
    val name: String,
    val detail: String,
    val url: String,
    val sizeMo: Int,   // 0 = taille inconnue
    val group: Int     // 0 = France, 1 = pays voisins
)

// Cartes vectorielles Mapsforge (fond de plan seul, sans relief : les plus légères).
// Source : https://download.mapsforge.org/maps/v5/europe/  (régions françaises d'avant 2016).
// Tailles relevées sur le serveur en août 2026 ; elles évoluent à chaque mise à jour.
// Pour ajouter une zone : ajouter une ligne ci-dessous.
object Zones {
    private const val FR = "https://download.mapsforge.org/maps/v5/europe/france/"
    private const val EU = "https://download.mapsforge.org/maps/v5/europe/"

    val all = listOf(
        Zone("fr-alsace", "Alsace", "Bas-Rhin, Haut-Rhin", FR + "alsace.map", 86, 0),
        Zone("fr-aquitaine", "Aquitaine", "Gironde, Landes, Dordogne, Lot-et-Garonne, Pyrénées-Atlantiques", FR + "aquitaine.map", 211, 0),
        Zone("fr-auvergne", "Auvergne", "Puy-de-Dôme, Cantal, Allier, Haute-Loire", FR + "auvergne.map", 113, 0),
        Zone("fr-basse-normandie", "Basse-Normandie", "Calvados, Manche, Orne", FR + "basse-normandie.map", 103, 0),
        Zone("fr-bourgogne", "Bourgogne", "Côte-d'Or, Saône-et-Loire, Yonne, Nièvre", FR + "bourgogne.map", 150, 0),
        Zone("fr-bretagne", "Bretagne", "Finistère, Morbihan, Côtes-d'Armor, Ille-et-Vilaine", FR + "bretagne.map", 207, 0),
        Zone("fr-centre", "Centre", "Loiret, Indre-et-Loire, Cher, Eure-et-Loir, Indre, Loir-et-Cher", FR + "centre.map", 175, 0),
        Zone("fr-champagne-ardenne", "Champagne-Ardenne", "Marne, Ardennes, Aube, Haute-Marne", FR + "champagne-ardenne.map", 79, 0),
        Zone("fr-corse", "Corse", "Corse-du-Sud, Haute-Corse", FR + "corse.map", 24, 0),
        Zone("fr-franche-comte", "Franche-Comté", "Doubs, Jura, Haute-Saône, Territoire de Belfort", FR + "franche-comte.map", 88, 0),
        Zone("fr-haute-normandie", "Haute-Normandie", "Seine-Maritime, Eure", FR + "haute-normandie.map", 78, 0),
        Zone("fr-ile-de-france", "Île-de-France", "Paris, Yvelines, Essonne, Hauts-de-Seine…", FR + "ile-de-france.map", 199, 0),
        Zone("fr-languedoc-roussillon", "Languedoc-Roussillon", "Hérault, Gard, Aude, Pyrénées-Orientales, Lozère", FR + "languedoc-roussillon.map", 170, 0),
        Zone("fr-limousin", "Limousin", "Haute-Vienne, Corrèze, Creuse", FR + "limousin.map", 73, 0),
        Zone("fr-lorraine", "Lorraine", "Meurthe-et-Moselle, Moselle, Meuse, Vosges", FR + "lorraine.map", 122, 0),
        Zone("fr-midi-pyrenees", "Midi-Pyrénées", "Haute-Garonne, Tarn, Aveyron, Lot, Gers…", FR + "midi-pyrenees.map", 244, 0),
        Zone("fr-nord-pas-de-calais", "Nord-Pas-de-Calais", "Nord, Pas-de-Calais", FR + "nord-pas-de-calais.map", 159, 0),
        Zone("fr-pays-de-la-loire", "Pays de la Loire", "Vendée, Loire-Atlantique, Maine-et-Loire, Mayenne, Sarthe", FR + "pays-de-la-loire.map", 238, 0),
        Zone("fr-picardie", "Picardie", "Somme, Oise, Aisne", FR + "picardie.map", 105, 0),
        Zone("fr-poitou-charentes", "Poitou-Charentes", "Charente-Maritime, Charente, Vienne, Deux-Sèvres", FR + "poitou-charentes.map", 147, 0),
        Zone("fr-rhone-alpes", "Rhône-Alpes", "Rhône, Isère, Savoie, Haute-Savoie, Ain…", FR + "rhone-alpes.map", 340, 0),
        // Non confirmé : fichier non vu dans la liste du serveur, taille inconnue.
        Zone("fr-paca", "Provence-Alpes-Côte d'Azur", "Bouches-du-Rhône, Var, Alpes-Maritimes… (lien non vérifié)", FR + "provence-alpes-cote-d-azur.map", 0, 0),
        Zone("fr-guadeloupe", "Guadeloupe", "Outre-mer", FR + "guadeloupe.map", 17, 0),
        Zone("fr-guyane", "Guyane", "Outre-mer", FR + "guyane.map", 15, 0),
        Zone("fr-martinique", "Martinique", "Outre-mer", FR + "martinique.map", 14, 0),
        Zone("fr-mayotte", "Mayotte", "Outre-mer", FR + "mayotte.map", 7, 0),
        Zone("fr-reunion", "La Réunion", "Outre-mer", FR + "reunion.map", 21, 0),

        // Liens non vérifiés : taille inconnue.
        Zone("eu-belgium", "Belgique", "Pays entier", EU + "belgium.map", 0, 1),
        Zone("eu-luxembourg", "Luxembourg", "Pays entier", EU + "luxembourg.map", 0, 1),
        Zone("eu-switzerland", "Suisse", "Pays entier", EU + "switzerland.map", 0, 1),
        Zone("eu-netherlands", "Pays-Bas", "Pays entier", EU + "netherlands.map", 0, 1),
        Zone("eu-portugal", "Portugal", "Pays entier", EU + "portugal.map", 0, 1)
    )
}
