package com.gpstracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.IBinder
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocationService : Service(), LocationListener {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.gpstracker.STOP"
        const val EXTRA_MINUTES = "minutes"
        const val EXTRA_MODE = "mode"
        private const val CHANNEL = "gps"
    }

    private lateinit var lm: LocationManager
    private var intervalMs = 0L
    private var lastSaved = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { finishRecording(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY

        intervalMs = (intent?.getIntExtra(EXTRA_MINUTES, 5) ?: 5) * 60_000L
        val mode = intent?.getStringExtra(EXTRA_MODE) ?: "Voiture"

        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        Store.pending(this).writeText(mode + "\n")
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, intervalMs, 0f, this)
        } catch (e: SecurityException) {
            stopSelf(); return START_NOT_STICKY
        }
        running = true
        return START_NOT_STICKY
    }

    override fun onLocationChanged(loc: Location) {
        val now = System.currentTimeMillis()
        if (lastSaved != 0L && now - lastSaved < intervalMs - 1000) return
        lastSaved = now
        Store.pending(this).appendText("${loc.time};${loc.latitude};${loc.longitude};${loc.altitude}\n")
    }

    private fun finishRecording() {
        if (::lm.isInitialized) lm.removeUpdates(this)
        running = false
        val f: File = Store.pending(this)
        if (f.exists()) {
            val lines = f.readLines()
            val modeFile = lines.firstOrNull() ?: "Voiture"
            val pts = lines.drop(1).filter { it.isNotBlank() }
            if (pts.isEmpty()) {
                Toast.makeText(this, "Aucun point enregistré", Toast.LENGTH_LONG).show()
            } else {
                val dFmt = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
                val tFmt = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)
                val label = Store.MODES.firstOrNull { it.second == modeFile }?.first ?: modeFile
                val rows = mutableListOf<List<Any>>()
                rows.add(listOf("N°", "Date", "Heure", "Latitude", "Longitude", "Altitude (m)", "Transport"))
                pts.forEachIndexed { i, line ->
                    val p = line.split(";")
                    val d = Date(p[0].toLong())
                    rows.add(listOf(
                        Num((i + 1).toString()), dFmt.format(d), tFmt.format(d),
                        Num(String.format(Locale.US, "%.7f", p[1].toDouble())),
                        Num(String.format(Locale.US, "%.7f", p[2].toDouble())),
                        Num(String.format(Locale.US, "%.1f", p[3].toDouble())),
                        label
                    ))
                }
                val base = Store.nextName(this, modeFile)
                val out = File(Store.dir(this), "$base.xlsx")
                XlsxWriter.write(out, rows)
                File(Store.dir(this), "$base.pts").writeText(
                    pts.joinToString("\n") { l -> val q = l.split(";"); "${q[1]};${q[2]}" }
                )
                Toast.makeText(this, "Enregistrement sauvegardé : ${out.nameWithoutExtension}", Toast.LENGTH_LONG).show()
            }
            f.delete()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (::lm.isInitialized) lm.removeUpdates(this)
        running = false
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Enregistrement GPS", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Traceur GPS")
            .setContentText("Enregistrement en cours")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }
}
