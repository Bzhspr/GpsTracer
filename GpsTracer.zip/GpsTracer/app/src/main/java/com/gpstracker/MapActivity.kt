package com.gpstracker

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import org.mapsforge.core.model.BoundingBox
import org.mapsforge.core.model.LatLong
import org.mapsforge.core.model.MapPosition
import org.mapsforge.core.util.LatLongUtils
import org.mapsforge.map.android.graphics.AndroidGraphicFactory
import org.mapsforge.map.android.util.AndroidUtil
import org.mapsforge.map.android.view.MapView
import org.mapsforge.map.datastore.MultiMapDataStore
import org.mapsforge.map.layer.cache.TileCache
import org.mapsforge.map.layer.download.TileDownloadLayer
import org.mapsforge.map.layer.renderer.TileRendererLayer
import org.mapsforge.map.model.common.Observer
import org.mapsforge.map.reader.MapFile
import org.mapsforge.map.rendertheme.InternalRenderTheme
import java.io.File
import kotlin.math.max
import kotlin.math.min

class MapActivity : AppCompatActivity() {

    companion object { const val EXTRA_NAME = "name" }

    private lateinit var mapView: MapView
    private lateinit var planCache: TileCache
    private lateinit var satCache: TileCache
    private lateinit var points: PointsLayer
    private lateinit var bulle: TextView
    private lateinit var info: TextView
    private lateinit var attrib: TextView
    private lateinit var btnSat: MaterialButton
    private lateinit var btnTrace: ImageButton

    private var planLayer: TileRendererLayer? = null
    private var satLayer: TileDownloadLayer? = null
    private var satellite = false
    private var fitted = false
    private var trace = false
    private val pts = ArrayList<LatLong>()
    private var density = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidGraphicFactory.createInstance(application)
        setContentView(R.layout.activity_map)
        density = resources.displayMetrics.density

        bulle = findViewById(R.id.bulle)
        info = findViewById(R.id.info)
        attrib = findViewById(R.id.attrib)
        btnSat = findViewById(R.id.satellite)
        btnTrace = findViewById(R.id.trace)

        val name = intent.getStringExtra(EXTRA_NAME) ?: ""
        val f = File(Store.dir(this), "$name.pts")
        if (f.exists()) {
            f.readLines().forEach { l ->
                val p = l.split(";")
                if (p.size >= 2) {
                    val la = p[0].toDoubleOrNull()
                    val lo = p[1].toDoubleOrNull()
                    if (la != null && lo != null) pts.add(LatLong(la, lo))
                }
            }
        }

        mapView = MapView(this)
        findViewById<FrameLayout>(R.id.mapContainer).addView(mapView)
        mapView.isClickable = true
        mapView.mapScaleBar.isVisible = true
        mapView.setZoomLevelMin(3.toByte())
        mapView.setZoomLevelMax(19.toByte())

        val tile = mapView.model.displayModel.tileSize
        val overdraw = mapView.model.frameBufferModel.overdrawFactor
        planCache = AndroidUtil.createTileCache(this, "plan", tile, 1f, overdraw)
        satCache = AndroidUtil.createTileCache(this, "sat", tile, 1f, overdraw)

        points = PointsLayer(pts, tile, density) { ll, label -> showBulle(ll, label) }
        mapView.layerManager.layers.add(points)

        mapView.model.mapViewPosition.addObserver(object : Observer {
            override fun onChange() { runOnUiThread { bulle.visibility = View.GONE } }
        })
        mapView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (!fitted) fitted = fit()
        }

        findViewById<ImageButton>(R.id.retour).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.zones).setOnClickListener {
            startActivity(android.content.Intent(this, ZonesActivity::class.java))
        }
        btnSat.setOnClickListener {
            if (!satellite && !Net.online(this)) {
                Toast.makeText(this, "Satellite indisponible hors ligne", Toast.LENGTH_LONG).show()
            } else setBase(!satellite)
        }
        btnTrace.setOnClickListener {
            trace = !trace
            points.showTrace = trace
            btnTrace.setBackgroundResource(if (trace) R.drawable.bg_circle_blue else R.drawable.bg_circle)
            btnTrace.setColorFilter(if (trace) Color.WHITE else Color.parseColor("#2C2C2A"))
            points.requestRedraw()
        }
        btnTrace.setColorFilter(Color.parseColor("#2C2C2A"))
        majUi()
    }

    override fun onResume() {
        super.onResume()
        buildPlan()
        if (satellite) satLayer?.onResume()
    }

    override fun onPause() {
        satLayer?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapView.destroyAll()
        planCache.destroy()
        satCache.destroy()
        AndroidGraphicFactory.clearResourceMemoryCache()
        super.onDestroy()
    }

    // Fond « plan » hors ligne : toutes les cartes téléchargées
    private fun buildPlan() {
        val layers = mapView.layerManager.layers
        planLayer?.let {
            layers.remove(it)
            it.onDestroy()
        }
        planLayer = null
        planCache.purge()
        val files = Store.maps(this).listFiles { f -> f.extension == "map" }.orEmpty()
        if (files.isNotEmpty()) {
            try {
                val store = MultiMapDataStore(MultiMapDataStore.DataPolicy.RETURN_ALL)
                files.forEach { store.addMapDataStore(MapFile(it), false, false) }
                val l = TileRendererLayer(
                    planCache, store, mapView.model.mapViewPosition, AndroidGraphicFactory.INSTANCE
                )
                l.setXmlRenderTheme(InternalRenderTheme.DEFAULT)
                planLayer = l
                if (!satellite) layers.add(0, l)
            } catch (e: Exception) {
                Toast.makeText(this, "Carte illisible : supprimez-la et retéléchargez-la", Toast.LENGTH_LONG).show()
            }
        }
        majUi()
    }

    private fun setBase(sat: Boolean) {
        val layers = mapView.layerManager.layers
        if (sat) {
            planLayer?.let { layers.remove(it) }
            val s = satLayer ?: TileDownloadLayer(
                satCache, mapView.model.mapViewPosition, EsriSource(), AndroidGraphicFactory.INSTANCE
            ).also { satLayer = it }
            layers.add(0, s)
            s.onResume()
        } else {
            satLayer?.let {
                it.onPause()
                layers.remove(it)
            }
            planLayer?.let { layers.add(0, it) }
        }
        satellite = sat
        majUi()
    }

    private fun majUi() {
        btnSat.text = if (satellite) "Plan" else "Satellite"
        attrib.text = if (satellite) "© Esri, Maxar, Earthstar Geographics" else "© contributeurs OpenStreetMap"
        info.visibility = if (planLayer == null && !satellite) View.VISIBLE else View.GONE
    }

    // Cadre la carte sur l'ensemble de la trace, nord en haut
    private fun fit(): Boolean {
        val dim = mapView.model.mapViewDimension.dimension ?: return false
        if (pts.isEmpty()) return true
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (p in pts) {
            minLat = min(minLat, p.latitude); maxLat = max(maxLat, p.latitude)
            minLon = min(minLon, p.longitude); maxLon = max(maxLon, p.longitude)
        }
        val padLat = max((maxLat - minLat) * 0.25, 0.0015)
        val padLon = max((maxLon - minLon) * 0.25, 0.0015)
        val bb = BoundingBox(
            max(minLat - padLat, -85.0), max(minLon - padLon, -179.9),
            min(maxLat + padLat, 85.0), min(maxLon + padLon, 179.9)
        )
        val z = LatLongUtils.zoomForBounds(dim, bb, mapView.model.displayModel.tileSize)
        mapView.model.mapViewPosition.mapPosition = MapPosition(bb.centerPoint, min(z.toInt(), 18).toByte())
        return true
    }

    private fun showBulle(ll: LatLong, label: String) {
        runOnUiThread {
            val p = mapView.mapViewProjection.toPixels(ll) ?: return@runOnUiThread
            bulle.text = label
            bulle.visibility = View.VISIBLE
            bulle.measure(0, 0)
            bulle.x = (p.x - bulle.measuredWidth / 2.0).toFloat()
            bulle.y = (p.y - bulle.measuredHeight - 30 * density).toFloat()
        }
    }
}
