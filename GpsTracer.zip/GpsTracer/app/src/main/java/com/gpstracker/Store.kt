package com.gpstracker

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    // (libellé affiché, libellé utilisé dans le nom du fichier)
    val MODES = listOf(
        "À pied" to "Pied", "Moto" to "Moto", "Voiture" to "Voiture",
        "Train" to "Train", "Bateau" to "Bateau", "Avion" to "Avion"
    )

    fun dir(c: Context): File = File(c.filesDir, "tracks").apply { mkdirs() }
    fun maps(c: Context): File = File(c.filesDir, "maps").apply { mkdirs() }
    fun pending(c: Context): File = File(c.filesDir, "pending.csv")

    // Fichier compagnon (latitude;longitude, une ligne par point) utilisé pour la carte
    fun ptsFile(xlsx: File): File = File(xlsx.parentFile, xlsx.nameWithoutExtension + ".pts")

    // Ex. 20261031_GPS_Avion_1 : le numéro repart à 1 chaque jour
    fun nextName(c: Context, mode: String): String {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val max = dir(c).listFiles().orEmpty().mapNotNull { f ->
            val n = f.nameWithoutExtension
            if (n.startsWith(day + "_GPS_")) n.substringAfterLast('_').toIntOrNull() else null
        }.maxOrNull() ?: 0
        return "${day}_GPS_${mode}_${max + 1}"
    }
}
