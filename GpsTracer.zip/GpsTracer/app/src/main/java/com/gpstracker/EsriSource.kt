package com.gpstracker

import org.mapsforge.core.model.Tile
import org.mapsforge.map.layer.download.tilesource.OnlineTileSource
import java.net.URL

// Fond satellite (images Esri World Imagery) : nécessite une connexion internet
class EsriSource : OnlineTileSource(arrayOf("server.arcgisonline.com"), 443) {
    init {
        setName("EsriImagery")
        setZoomLevelMin(0.toByte())
        setZoomLevelMax(19.toByte())
    }

    override fun getTileUrl(tile: Tile): URL {
        return URL(
            "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/" +
                "${tile.zoomLevel.toInt()}/${tile.tileY}/${tile.tileX}"
        )
    }
}
