package com.gpstracker

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.Collator
import java.util.Locale

class ZonesActivity : AppCompatActivity() {

    private lateinit var liste: LinearLayout
    private lateinit var banner: TextView
    private lateinit var stock: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zones)
        liste = findViewById(R.id.liste)
        banner = findViewById(R.id.banner)
        stock = findViewById(R.id.stock)
        findViewById<ImageButton>(R.id.back).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        Downloads.listener = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        Downloads.listener = null
        super.onPause()
    }

    private fun fmt(bytes: Long): String {
        val mo = bytes / (1024.0 * 1024.0)
        return if (mo >= 1000) String.format(Locale.FRANCE, "%.1f Go", mo / 1024.0)
        else String.format(Locale.FRANCE, "%.0f Mo", mo)
    }

    private fun refresh() {
        val online = Net.online(this)
        banner.text = if (online) "Connecté · téléchargement possible" else "Hors ligne · téléchargement impossible"
        banner.setBackgroundColor(Color.parseColor(if (online) "#EAF3DE" else "#FCEBEB"))
        banner.setTextColor(Color.parseColor(if (online) "#3B6D11" else "#A32D2D"))

        Downloads.error?.let {
            Toast.makeText(this, "Téléchargement impossible : $it", Toast.LENGTH_LONG).show()
            Downloads.error = null
        }

        liste.removeAllViews()
        val collator = Collator.getInstance(Locale.FRANCE)
        val dir = Store.maps(this)
        var total = 0L

        val titres = listOf(0 to "France · régions", 1 to "Pays voisins · liens non vérifiés")
        for ((g, titre) in titres) {
            val h = TextView(this)
            h.text = titre
            h.textSize = 13f
            h.setTextColor(Color.parseColor("#5F5E5A"))
            h.setPadding(0, if (g == 0) 12 else 28, 0, 4)
            liste.addView(h)

            Zones.all.filter { it.group == g }.sortedWith { a, b -> collator.compare(a.name, b.name) }.forEach { z ->
                val row = layoutInflater.inflate(R.layout.item_zone, liste, false)
                row.findViewById<TextView>(R.id.nom).text = z.name
                val detail = row.findViewById<TextView>(R.id.detail)
                val bar = row.findViewById<ProgressBar>(R.id.progres)
                val action = row.findViewById<ImageButton>(R.id.action)
                val file = File(dir, z.id + ".map")
                val p = Downloads.progress[z.id]

                if (file.exists()) {
                    total += file.length()
                    detail.text = "Téléchargée · " + fmt(file.length())
                    detail.setTextColor(Color.parseColor("#3B6D11"))
                    action.setImageResource(R.drawable.ic_delete)
                    action.contentDescription = "Supprimer " + z.name
                    action.setOnClickListener {
                        AlertDialog.Builder(this)
                            .setTitle("Supprimer cette carte ?")
                            .setMessage(z.name)
                            .setPositiveButton("Supprimer") { _, _ -> file.delete(); refresh() }
                            .setNegativeButton("Annuler", null)
                            .show()
                    }
                } else if (p != null) {
                    detail.text = "Téléchargement… $p %"
                    bar.visibility = View.VISIBLE
                    bar.progress = p
                    action.setImageResource(R.drawable.ic_close)
                    action.contentDescription = "Annuler"
                    action.setOnClickListener { Downloads.cancel(z.id) }
                } else {
                    val taille = if (z.sizeMo > 0) "≈ ${z.sizeMo} Mo · " else "taille variable · "
                    detail.text = taille + z.detail
                    action.setImageResource(R.drawable.ic_download)
                    action.contentDescription = "Télécharger " + z.name
                    action.setOnClickListener {
                        if (!Net.online(this)) {
                            Toast.makeText(this, "Pas de connexion", Toast.LENGTH_LONG).show()
                        } else Downloads.start(this, z)
                    }
                }
                liste.addView(row)
            }
        }
        stock.text = "Espace utilisé : " + (if (total > 0) fmt(total) else "0 Mo")
    }
}
