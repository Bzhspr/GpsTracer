plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gpstracker"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gpstracker"
        minSdk = 31
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += listOf("META-INF/AL2.0", "META-INF/LGPL2.1") } }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.mapsforge:mapsforge-core:0.21.0")
    implementation("org.mapsforge:mapsforge-map:0.21.0")
    implementation("org.mapsforge:mapsforge-map-reader:0.21.0")
    implementation("org.mapsforge:mapsforge-themes:0.21.0")
    implementation("org.mapsforge:mapsforge-map-android:0.21.0")
    implementation("com.caverock:androidsvg:1.4")
}
